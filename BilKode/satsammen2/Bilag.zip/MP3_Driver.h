/*
 * MP3_Driver.h
 *
 * Created: 15-05-2019 09:48:09
 *  Author: Bastian
 */ 
void initMP3();
void playSound(char soundChoice);