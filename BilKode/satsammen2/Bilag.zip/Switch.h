/*
 * Switch.h
 *
 * Created: 15-05-2019 10:22:01
 *  Author: einar
 */ 


#ifndef SWITCH_H_
#define SWITCH_H_

void initSwitchPort();


#endif /* SWITCH_H_ */