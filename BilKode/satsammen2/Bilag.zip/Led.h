/*
 * Led1.h
 *
 * Created: 15-05-2019 08:33:19
 *  Author: einar
 */ 


#ifndef LED1_H_
#define LED1_H_
void initLedPort();
void turnOn();
void turnOff();
void brake();


#endif /* LED1_H_ */